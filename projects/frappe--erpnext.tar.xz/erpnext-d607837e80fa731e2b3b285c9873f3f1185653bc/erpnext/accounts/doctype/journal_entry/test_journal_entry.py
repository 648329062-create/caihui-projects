# Copyright (c) 2015, Frappe Technologies Pvt. Ltd. and Contributors
# License: GNU General Public License v3. See license.txt

import frappe
from frappe.utils import add_days, flt, nowdate

from erpnext.accounts.doctype.account.test_account import get_inventory_account
from erpnext.accounts.doctype.journal_entry.journal_entry import StockAccountInvalidTransaction
from erpnext.exceptions import InvalidAccountCurrency
from erpnext.selling.doctype.customer.test_customer import make_customer, set_credit_limit
from erpnext.tests.utils import ERPNextTestSuite


class TestJournalEntry(ERPNextTestSuite):
	def setUp(self):
		self.load_test_records("Journal Entry")

	@ERPNextTestSuite.change_settings("Accounts Settings", {"unlink_payment_on_cancellation_of_invoice": 1})
	def test_journal_entry_with_against_jv(self):
		jv_invoice = frappe.copy_doc(self.globalTestRecords["Journal Entry"][2])
		base_jv = frappe.copy_doc(self.globalTestRecords["Journal Entry"][0])
		self.jv_against_voucher_testcase(base_jv, jv_invoice)

	def test_jv_against_sales_order(self):
		from erpnext.selling.doctype.sales_order.test_sales_order import make_sales_order

		sales_order = make_sales_order(do_not_save=True)
		base_jv = frappe.copy_doc(self.globalTestRecords["Journal Entry"][0])
		self.jv_against_voucher_testcase(base_jv, sales_order)

	def test_jv_against_purchase_order(self):
		from erpnext.buying.doctype.purchase_order.test_purchase_order import create_purchase_order

		purchase_order = create_purchase_order(do_not_save=True)
		base_jv = frappe.copy_doc(self.globalTestRecords["Journal Entry"][1])
		self.jv_against_voucher_testcase(base_jv, purchase_order)

	def jv_against_voucher_testcase(self, base_jv, test_voucher):
		dr_or_cr = "credit" if test_voucher.doctype in ["Sales Order", "Journal Entry"] else "debit"

		test_voucher.insert()
		test_voucher.submit()

		if test_voucher.doctype == "Journal Entry":
			self.assertTrue(
				frappe.get_all(
					"Journal Entry Account",
					filters={"account": "Debtors - _TC", "docstatus": 1, "parent": test_voucher.name},
					pluck="name",
				)
			)

		self.assertFalse(
			frappe.get_all(
				"Journal Entry Account",
				filters={"reference_type": test_voucher.doctype, "reference_name": test_voucher.name},
				pluck="name",
			)
		)

		base_jv.get("accounts")[0].is_advance = (
			"Yes" if (test_voucher.doctype in ["Sales Order", "Purchase Order"]) else "No"
		)
		base_jv.get("accounts")[0].set("reference_type", test_voucher.doctype)
		base_jv.get("accounts")[0].set("reference_name", test_voucher.name)
		base_jv.insert()
		base_jv.submit()

		submitted_voucher = frappe.get_doc(test_voucher.doctype, test_voucher.name)

		self.assertTrue(
			frappe.get_all(
				"Journal Entry Account",
				filters={
					"reference_type": submitted_voucher.doctype,
					"reference_name": submitted_voucher.name,
					dr_or_cr: 400,
				},
				pluck="name",
			)
		)

		if base_jv.get("accounts")[0].is_advance == "Yes":
			self.advance_paid_testcase(base_jv, submitted_voucher, dr_or_cr)
		self.cancel_against_voucher_testcase(submitted_voucher)

	def advance_paid_testcase(self, base_jv, test_voucher, dr_or_cr):
		# Test advance paid field
		advance_paid = frappe.db.get_value(test_voucher.doctype, test_voucher.name, "advance_paid")
		payment_against_order = base_jv.get("accounts")[0].get(dr_or_cr)

		self.assertEqual(flt(advance_paid), flt(payment_against_order))

	def cancel_against_voucher_testcase(self, test_voucher):
		if test_voucher.doctype == "Journal Entry":
			# if test_voucher is a Journal Entry, test cancellation of test_voucher
			test_voucher.cancel()
			self.assertFalse(
				frappe.get_all(
					"Journal Entry Account",
					filters={"reference_type": "Journal Entry", "reference_name": test_voucher.name},
					pluck="name",
				)
			)

		elif test_voucher.doctype in ["Sales Order", "Purchase Order"]:
			# if test_voucher is a Sales Order/Purchase Order, test error on cancellation of test_voucher
			frappe.db.set_single_value(
				"Accounts Settings", "unlink_advance_payment_on_cancelation_of_order", 0
			)
			submitted_voucher = frappe.get_doc(test_voucher.doctype, test_voucher.name)
			self.assertRaises(frappe.LinkExistsError, submitted_voucher.cancel)

	def test_jv_against_stock_account(self):
		company = "_Test Company with perpetual inventory"
		stock_account = get_inventory_account(company)

		from erpnext.accounts.utils import get_stock_and_account_balance

		account_bal, stock_bal, warehouse_list = get_stock_and_account_balance(
			stock_account, nowdate(), company
		)
		diff = flt(account_bal) - flt(stock_bal)

		if not diff:
			diff = 100

		jv = frappe.new_doc("Journal Entry")
		jv.company = company
		jv.posting_date = nowdate()
		jv.append(
			"accounts",
			{
				"account": stock_account,
				"cost_center": "Main - TCP1",
				"debit_in_account_currency": 0 if diff > 0 else abs(diff),
				"credit_in_account_currency": diff if diff > 0 else 0,
			},
		)

		jv.append(
			"accounts",
			{
				"account": "Stock Adjustment - TCP1",
				"cost_center": "Main - TCP1",
				"debit_in_account_currency": diff if diff > 0 else 0,
				"credit_in_account_currency": 0 if diff > 0 else abs(diff),
			},
		)

		if account_bal == stock_bal:
			self.assertRaises(StockAccountInvalidTransaction, jv.save)
		else:
			jv.submit()
			jv.cancel()

	def test_multi_currency(self):
		jv = make_journal_entry("_Test Bank USD - _TC", "_Test Bank - _TC", 100, exchange_rate=50, save=False)

		jv.get("accounts")[1].credit_in_account_currency = 5000
		jv.submit()

		self.voucher_no = jv.name

		self.fields = [
			"account",
			"account_currency",
			"debit",
			"debit_in_account_currency",
			"credit",
			"credit_in_account_currency",
			"debit_in_transaction_currency",
			"credit_in_transaction_currency",
		]

		# Transaction currency is USD (first foreign row); the INR row is converted at 1/50.
		self.expected_gle = [
			{
				"account": "_Test Bank - _TC",
				"account_currency": "INR",
				"debit": 0,
				"debit_in_account_currency": 0,
				"credit": 5000,
				"credit_in_account_currency": 5000,
				"debit_in_transaction_currency": 0,
				"credit_in_transaction_currency": 100,
			},
			{
				"account": "_Test Bank USD - _TC",
				"account_currency": "USD",
				"debit": 5000,
				"debit_in_account_currency": 100,
				"credit": 0,
				"credit_in_account_currency": 0,
				"debit_in_transaction_currency": 100,
				"credit_in_transaction_currency": 0,
			},
		]

		self.check_gl_entries()

		# cancel
		jv.cancel()

		gle = frappe.get_all(
			"GL Entry",
			filters={"voucher_type": "Sales Invoice", "voucher_no": jv.name},
			pluck="name",
		)

		self.assertFalse(gle)

	def test_multi_currency_transaction_currency_on_foreign_debit(self):
		"""Pin debit_in_transaction_currency for a foreign-currency debit row.

		Transaction currency is USD (the first foreign row); the INR debit row must be
		converted at 1/exchange_rate, so 5000 INR -> 100 USD. Guards the / vs * direction.
		"""
		jv = frappe.new_doc("Journal Entry")
		jv.company = "_Test Company"
		jv.posting_date = nowdate()
		jv.multi_currency = 1
		jv.append(
			"accounts",
			{
				"account": "_Test Bank USD - _TC",
				"cost_center": "_Test Cost Center - _TC",
				"credit_in_account_currency": 100,
				"exchange_rate": 50,
			},
		)
		jv.append(
			"accounts",
			{
				"account": "_Test Bank - _TC",
				"cost_center": "_Test Cost Center - _TC",
				"debit_in_account_currency": 5000,
				"exchange_rate": 1,
			},
		)
		jv.submit()

		self.voucher_no = jv.name
		self.fields = ["account", "debit_in_transaction_currency", "credit_in_transaction_currency"]
		self.expected_gle = [
			{
				"account": "_Test Bank - _TC",
				"debit_in_transaction_currency": 100,
				"credit_in_transaction_currency": 0,
			},
			{
				"account": "_Test Bank USD - _TC",
				"debit_in_transaction_currency": 0,
				"credit_in_transaction_currency": 100,
			},
		]
		self.check_gl_entries()

	def test_reverse_journal_entry(self):
		from erpnext.accounts.doctype.journal_entry.mapper import make_reverse_journal_entry

		jv = make_journal_entry("_Test Bank USD - _TC", "Sales - _TC", 100, exchange_rate=50, save=False)

		jv.get("accounts")[1].credit_in_account_currency = 5000
		jv.get("accounts")[1].exchange_rate = 1
		jv.submit()

		rjv = make_reverse_journal_entry(jv.name)
		rjv.posting_date = nowdate()
		rjv.submit()

		self.voucher_no = rjv.name

		self.fields = [
			"account",
			"account_currency",
			"debit",
			"credit",
			"debit_in_account_currency",
			"credit_in_account_currency",
		]

		self.expected_gle = [
			{
				"account": "_Test Bank USD - _TC",
				"account_currency": "USD",
				"debit": 0,
				"debit_in_account_currency": 0,
				"credit": 5000,
				"credit_in_account_currency": 100,
			},
			{
				"account": "Sales - _TC",
				"account_currency": "INR",
				"debit": 5000,
				"debit_in_account_currency": 5000,
				"credit": 0,
				"credit_in_account_currency": 0,
			},
		]

		self.check_gl_entries()

	def test_disallow_reversal_of_a_reversal_journal_entry(self):
		from erpnext.accounts.doctype.journal_entry.mapper import make_reverse_journal_entry

		jv = make_journal_entry("_Test Bank - _TC", "Sales - _TC", 100, submit=True)

		rjv = make_reverse_journal_entry(jv.name)
		rjv.posting_date = nowdate()
		rjv.submit()

		self.assertRaisesRegex(
			frappe.ValidationError,
			"is already a Reverse Journal Entry",
			make_reverse_journal_entry,
			rjv.name,
		)

		# the guard must not disclose the reversal to a user who cannot read the entry
		with self.set_user("Guest"):
			self.assertRaises(frappe.PermissionError, make_reverse_journal_entry, rjv.name)

	def test_disallow_change_in_account_currency_for_a_party(self):
		# create jv in USD
		jv = make_journal_entry("_Test Bank USD - _TC", "_Test Receivable USD - _TC", 100, save=False)

		jv.accounts[1].update({"party_type": "Customer", "party": "_Test Customer USD"})

		jv.submit()

		# create jv in USD, but account currency in INR
		jv = make_journal_entry("_Test Bank - _TC", "Debtors - _TC", 100, save=False)

		jv.accounts[1].update({"party_type": "Customer", "party": "_Test Customer USD"})

		self.assertRaises(InvalidAccountCurrency, jv.submit)

		# back in USD
		jv = make_journal_entry("_Test Bank USD - _TC", "_Test Receivable USD - _TC", 100, save=False)

		jv.accounts[1].update({"party_type": "Customer", "party": "_Test Customer USD"})

		jv.submit()

	def test_inter_company_jv(self):
		jv = make_journal_entry(
			"Sales Expenses - _TC",
			"Buildings - _TC",
			100,
			posting_date=nowdate(),
			cost_center="Main - _TC",
			save=False,
		)
		jv.voucher_type = "Inter Company Journal Entry"
		jv.multi_currency = 0
		jv.insert()
		jv.submit()

		jv1 = make_journal_entry(
			"Sales Expenses - _TC1",
			"Buildings - _TC1",
			100,
			posting_date=nowdate(),
			cost_center="Main - _TC1",
			save=False,
		)
		jv1.inter_company_journal_entry_reference = jv.name
		jv1.company = "_Test Company 1"
		jv1.voucher_type = "Inter Company Journal Entry"
		jv1.multi_currency = 0
		jv1.insert()
		jv1.submit()

		jv.reload()

		self.assertEqual(jv.inter_company_journal_entry_reference, jv1.name)
		self.assertEqual(jv1.inter_company_journal_entry_reference, jv.name)

		jv.cancel()
		jv1.reload()
		jv.reload()

		self.assertEqual(jv.inter_company_journal_entry_reference, "")
		self.assertEqual(jv1.inter_company_journal_entry_reference, "")

	def test_validate_account_company_mismatch_on_save(self):
		# Switching Company after the accounts table is filled in (without updating the
		# accounts to match) must be rejected on save -- previously this only surfaced as a
		# GL Entry error on submit, letting a mismatched draft sit around silently.
		jv = make_journal_entry(
			"Sales Expenses - _TC",
			"Buildings - _TC",
			100,
			posting_date=nowdate(),
			cost_center="Main - _TC",
			save=True,
		)

		jv.company = "_Test Company 1"
		for row in jv.accounts:
			row.cost_center = "Main - _TC1"
		self.assertRaises(frappe.ValidationError, jv.save)

	def test_jv_with_cost_centre(self):
		from erpnext.accounts.doctype.cost_center.test_cost_center import create_cost_center

		cost_center = "_Test Cost Center for BS Account - _TC"
		create_cost_center(cost_center_name="_Test Cost Center for BS Account", company="_Test Company")
		jv = make_journal_entry(
			"_Test Cash - _TC", "_Test Bank - _TC", 100, cost_center=cost_center, save=False
		)
		jv.voucher_type = "Bank Entry"
		jv.multi_currency = 0
		jv.cheque_no = "112233"
		jv.cheque_date = nowdate()
		jv.insert()
		jv.submit()

		self.voucher_no = jv.name

		self.fields = [
			"account",
			"cost_center",
		]

		self.expected_gle = [
			{
				"account": "_Test Bank - _TC",
				"cost_center": cost_center,
			},
			{
				"account": "_Test Cash - _TC",
				"cost_center": cost_center,
			},
		]

		self.check_gl_entries()

	def test_jv_with_project(self):
		from erpnext.projects.doctype.project.test_project import make_project

		if not frappe.db.exists("Project", {"project_name": "Journal Entry Project"}):
			project = make_project(
				{
					"project_name": "Journal Entry Project",
					"project_template_name": "Test Project Template",
					"start_date": "2020-01-01",
				}
			)
			project_name = project.name
		else:
			project_name = frappe.get_value("Project", {"project_name": "_Test Project"})

		jv = make_journal_entry("_Test Cash - _TC", "_Test Bank - _TC", 100, save=False)
		for d in jv.accounts:
			d.project = project_name
		jv.voucher_type = "Bank Entry"
		jv.multi_currency = 0
		jv.cheque_no = "112233"
		jv.cheque_date = nowdate()
		jv.insert()
		jv.submit()

		self.voucher_no = jv.name

		self.fields = ["account", "project"]

		self.expected_gle = [
			{
				"account": "_Test Bank - _TC",
				"project": project_name,
			},
			{
				"account": "_Test Cash - _TC",
				"project": project_name,
			},
		]

		self.check_gl_entries()

	def make_jv_with_fractional_totals(self):
		"""0.10 + 0.20 sums to 0.30000000000000004, the residue this guards against."""
		jv = frappe.new_doc("Journal Entry")
		jv.posting_date = nowdate()
		jv.company = "_Test Company"
		jv.voucher_type = "Journal Entry"
		jv.remark = "test"
		for amount in (0.10, 0.20):
			jv.append(
				"accounts",
				{
					"account": "_Test Cash - _TC",
					"cost_center": "_Test Cost Center - _TC",
					"debit_in_account_currency": amount,
				},
			)
		jv.append(
			"accounts",
			{
				"account": "_Test Bank - _TC",
				"cost_center": "_Test Cost Center - _TC",
				"credit_in_account_currency": 0.30,
			},
		)
		jv.insert()
		return jv

	def test_totals_are_rounded_to_precision(self):
		jv = self.make_jv_with_fractional_totals()
		jv.submit()

		stored = frappe.db.get_value(
			"Journal Entry", jv.name, ["total_debit", "total_credit", "difference"], as_dict=True
		)
		self.assertEqual(jv.total_debit, flt(jv.total_debit, jv.precision("total_debit")))
		self.assertEqual(jv.total_credit, flt(jv.total_credit, jv.precision("total_credit")))
		self.assertEqual(jv.total_debit, stored.total_debit)
		self.assertEqual(jv.total_credit, stored.total_credit)
		self.assertEqual(jv.difference, stored.difference)

	def test_update_after_submit_with_fractional_totals(self):
		"""An unrounded total is stored rounded, so updating a submitted entry used to throw."""
		jv = self.make_jv_with_fractional_totals()
		jv.submit()

		jv.pay_to_recd_from = "_Test Supplier"
		jv.save()

		self.assertEqual(jv.docstatus, 1)
		self.assertEqual(
			jv.pay_to_recd_from, frappe.db.get_value("Journal Entry", jv.name, "pay_to_recd_from")
		)

	def test_jv_account_and_party_balance_with_cost_centre(self):
		from erpnext.accounts.doctype.cost_center.test_cost_center import create_cost_center
		from erpnext.accounts.utils import get_balance_on

		cost_center = "_Test Cost Center for BS Account - _TC"
		create_cost_center(cost_center_name="_Test Cost Center for BS Account", company="_Test Company")
		jv = make_journal_entry(
			"_Test Cash - _TC", "_Test Bank - _TC", 100, cost_center=cost_center, save=False
		)
		account_balance = get_balance_on(account="_Test Bank - _TC", cost_center=cost_center)
		jv.voucher_type = "Bank Entry"
		jv.multi_currency = 0
		jv.cheque_no = "112233"
		jv.cheque_date = nowdate()
		jv.insert()
		jv.submit()

		expected_account_balance = account_balance - 100
		account_balance = get_balance_on(account="_Test Bank - _TC", cost_center=cost_center)
		self.assertEqual(expected_account_balance, account_balance)

	def test_repost_accounting_entries(self):
		from erpnext.accounts.doctype.cost_center.test_cost_center import create_cost_center

		# Configure Repost Accounting Ledger for JVs
		settings = frappe.get_doc("Accounts Settings")
		if "Journal Entry" not in [x.document_type for x in settings.repost_allowed_types]:
			settings.append("repost_allowed_types", {"document_type": "Journal Entry"})
		settings.save()

		# Create JV with defaut cost center - _Test Cost Center
		jv = make_journal_entry("_Test Cash - _TC", "_Test Bank - _TC", 100, save=False)
		jv.multi_currency = 0
		jv.submit()

		# Check GL entries before reposting
		self.voucher_no = jv.name

		self.fields = [
			"account",
			"debit_in_account_currency",
			"credit_in_account_currency",
			"cost_center",
		]

		self.expected_gle = [
			{
				"account": "_Test Bank - _TC",
				"debit_in_account_currency": 0,
				"credit_in_account_currency": 100,
				"cost_center": "_Test Cost Center - _TC",
			},
			{
				"account": "_Test Cash - _TC",
				"debit_in_account_currency": 100,
				"credit_in_account_currency": 0,
				"cost_center": "_Test Cost Center - _TC",
			},
		]

		self.check_gl_entries()

		# Change cost center for bank account - _Test Cost Center for BS Account
		create_cost_center(cost_center_name="_Test Cost Center for BS Account", company="_Test Company")
		jv.accounts[1].cost_center = "_Test Cost Center for BS Account - _TC"
		# Ledger reposted implicitly upon 'Update After Submit'
		jv.save()

		# Check GL entries after reposting
		jv.load_from_db()
		self.expected_gle[0]["cost_center"] = "_Test Cost Center for BS Account - _TC"
		self.check_gl_entries()

	def check_gl_entries(self):
		gl = frappe.qb.DocType("GL Entry")
		query = frappe.qb.from_(gl)
		for field in self.fields:
			query = query.select(gl[field])

		query = query.where(
			(gl.voucher_type == "Journal Entry") & (gl.voucher_no == self.voucher_no) & (gl.is_cancelled == 0)
		).orderby(gl.account)

		gl_entries = query.run(as_dict=True)

		# MariaDB and Postgres collate `account` differently, so the DB ordering isn't portable;
		# sort both sides identically before the positional comparison.
		def _key(row):
			return tuple(str(row[f]) for f in self.fields)

		gl_entries = sorted(gl_entries, key=_key)
		expected_gle = sorted(self.expected_gle, key=_key)
		for i in range(len(expected_gle)):
			for field in self.fields:
				self.assertEqual(expected_gle[i][field], gl_entries[i][field])

	def test_negative_debit_and_credit_with_same_account_head(self):
		from erpnext.accounts.general_ledger import process_gl_map

		# Create JV with defaut cost center - _Test Cost Center
		frappe.db.set_single_value("Accounts Settings", "merge_similar_account_heads", 0)

		jv = make_journal_entry("_Test Bank - _TC", "_Test Bank - _TC", 100 * -1, save=True)
		jv.append(
			"accounts",
			{
				"account": "_Test Cash - _TC",
				"debit": 100 * -1,
				"credit": 100 * -1,
				"debit_in_account_currency": 100 * -1,
				"credit_in_account_currency": 100 * -1,
				"exchange_rate": 1,
			},
		)
		jv.flags.ignore_validate = True
		jv.save()

		self.assertEqual(len(jv.accounts), 3)

		gl_map = jv.build_gl_map()

		for row in gl_map:
			if row.account == "_Test Cash - _TC":
				self.assertEqual(row.debit_in_account_currency, 100 * -1)
				self.assertEqual(row.credit_in_account_currency, 100 * -1)

		gl_map = process_gl_map(gl_map, False)

		for row in gl_map:
			if row.account == "_Test Cash - _TC":
				self.assertEqual(row.debit_in_account_currency, 100)
				self.assertEqual(row.credit_in_account_currency, 100)

	def test_toggle_debit_credit_if_negative(self):
		from erpnext.accounts.general_ledger import process_gl_map

		# Create JV with defaut cost center - _Test Cost Center
		frappe.db.set_single_value("Accounts Settings", "merge_similar_account_heads", 0)

		jv = frappe.new_doc("Journal Entry")
		jv.posting_date = nowdate()
		jv.company = "_Test Company"
		jv.remark = "test"
		jv.extend(
			"accounts",
			[
				{
					"account": "_Test Cash - _TC",
					"debit": 100 * -1,
					"debit_in_account_currency": 100 * -1,
					"exchange_rate": 1,
				},
				{
					"account": "_Test Bank - _TC",
					"credit": 100 * -1,
					"credit_in_account_currency": 100 * -1,
					"exchange_rate": 1,
				},
			],
		)

		jv.flags.ignore_validate = True
		jv.save()

		self.assertEqual(len(jv.accounts), 2)

		gl_map = jv.build_gl_map()

		for row in gl_map:
			if row.account == "_Test Cash - _TC":
				self.assertEqual(row.debit, 100 * -1)
				self.assertEqual(row.debit_in_account_currency, 100 * -1)
				self.assertEqual(row.debit_in_transaction_currency, 100 * -1)

		gl_map = process_gl_map(gl_map, False)

		for row in gl_map:
			if row.account == "_Test Cash - _TC":
				self.assertEqual(row.credit, 100)
				self.assertEqual(row.credit_in_account_currency, 100)
				self.assertEqual(row.credit_in_transaction_currency, 100)

	def test_transaction_exchange_rate_on_journals(self):
		jv = make_journal_entry("_Test Bank - _TC", "_Test Receivable USD - _TC", 100, save=False)
		jv.accounts[0].update({"debit_in_account_currency": 8500, "exchange_rate": 1})
		jv.accounts[1].update({"party_type": "Customer", "party": "_Test Customer USD", "exchange_rate": 85})
		jv.submit()
		actual = frappe.db.get_all(
			"GL Entry",
			filters={"voucher_no": jv.name, "is_cancelled": 0},
			fields=["account", "transaction_exchange_rate"],
			order_by="account",
		)
		expected = [
			{"account": "_Test Bank - _TC", "transaction_exchange_rate": 85.0},
			{"account": "_Test Receivable USD - _TC", "transaction_exchange_rate": 85.0},
		]
		self.assertEqual(expected, actual)

	def test_pay_to_recd_from(self):
		jv = make_journal_entry("_Test Cash - _TC", "_Test Bank - _TC", 100, save=False)
		jv.pay_to_recd_from = "_Test Receiver"
		jv.save()
		self.assertEqual(jv.pay_to_recd_from, "_Test Receiver")

		jv.pay_to_recd_from = "_Test Receiver 2"
		jv.save()
		jv.submit()

		self.assertEqual(jv.pay_to_recd_from, "_Test Receiver 2")

	def test_custom_remark(self):
		# When custom_remark is enabled, remark should not be auto-overwritten on save
		jv = make_journal_entry("_Test Cash - _TC", "_Test Bank - _TC", 100, save=False)
		jv.custom_remark = 1
		jv.remark = "My custom remark text"
		jv.insert()
		self.assertEqual(jv.remark, "My custom remark text")

	def test_credit_limit_for_customer(self):
		customer = make_customer("_Test New Customer")
		set_credit_limit("_Test New Customer", "_Test Company", 50)
		jv = make_journal_entry(account1="Debtors - _TC", account2="_Test Cash - _TC", amount=100, save=False)
		jv.accounts[0].party_type = "Customer"
		jv.accounts[0].party = customer
		jv.save()
		self.assertRaises(frappe.ValidationError, jv.submit)

	def test_validate_reference_doc_debit_against_sales_order_throws(self):
		"""Characterize: a debit entry linked to a Sales Order is rejected."""
		from erpnext.selling.doctype.sales_order.test_sales_order import make_sales_order

		sales_order = make_sales_order()
		jv = make_journal_entry("Debtors - _TC", "_Test Cash - _TC", 100, save=False)
		jv.accounts[0].party_type = "Customer"
		jv.accounts[0].party = "_Test Customer"
		jv.accounts[0].reference_type = "Sales Order"
		jv.accounts[0].reference_name = sales_order.name
		self.assertRaisesRegex(frappe.ValidationError, "Debit entry can not be linked", jv.insert)

	def test_validate_reference_doc_credit_against_purchase_order_throws(self):
		"""Characterize: a credit entry linked to a Purchase Order is rejected."""
		from erpnext.buying.doctype.purchase_order.test_purchase_order import create_purchase_order

		purchase_order = create_purchase_order()
		jv = make_journal_entry("_Test Cash - _TC", "Creditors - _TC", 100, save=False)
		jv.accounts[1].party_type = "Supplier"
		jv.accounts[1].party = "_Test Supplier"
		jv.accounts[1].reference_type = "Purchase Order"
		jv.accounts[1].reference_name = purchase_order.name
		self.assertRaisesRegex(frappe.ValidationError, "Credit entry can not be linked", jv.insert)

	def test_validate_reference_doc_nonexistent_reference_rejected(self):
		"""Characterize: a JE referencing a non-existent invoice is rejected by link validation.

		Note: the controller's own "Invalid reference" branch is unreachable in normal flow
		because Frappe link validation rejects the missing reference before validate_reference_doc.
		"""
		jv = make_journal_entry("_Test Cash - _TC", "Debtors - _TC", 100, save=False)
		jv.accounts[1].party_type = "Customer"
		jv.accounts[1].party = "_Test Customer"
		jv.accounts[1].reference_type = "Sales Invoice"
		jv.accounts[1].reference_name = "NON-EXISTENT-SI"
		self.assertRaises(frappe.LinkValidationError, jv.insert)

	def test_validate_reference_doc_invoice_party_mismatch_throws(self):
		"""Characterize: an invoice reference whose party differs from the row party is rejected."""
		from erpnext.accounts.doctype.sales_invoice.test_sales_invoice import create_sales_invoice

		invoice = create_sales_invoice(rate=500)
		other_customer = make_customer("_Test JE Mismatch Customer")
		jv = make_journal_entry("_Test Cash - _TC", "Debtors - _TC", 100, save=False)
		jv.accounts[1].party_type = "Customer"
		jv.accounts[1].party = other_customer
		jv.accounts[1].reference_type = "Sales Invoice"
		jv.accounts[1].reference_name = invoice.name
		self.assertRaisesRegex(frappe.ValidationError, "Party / Account does not match", jv.insert)

	def test_validate_reference_doc_order_party_mismatch_throws(self):
		"""Characterize: a Sales Order reference whose party differs from the row party is rejected."""
		from erpnext.selling.doctype.sales_order.test_sales_order import make_sales_order

		sales_order = make_sales_order()
		other_customer = make_customer("_Test JE Mismatch Customer")
		jv = make_journal_entry("_Test Cash - _TC", "Debtors - _TC", 100, save=False)
		jv.accounts[1].party_type = "Customer"
		jv.accounts[1].party = other_customer
		jv.accounts[1].is_advance = "Yes"
		jv.accounts[1].reference_type = "Sales Order"
		jv.accounts[1].reference_name = sales_order.name
		self.assertRaisesRegex(frappe.ValidationError, "does not match", jv.insert)

	def test_validate_reference_doc_populates_reference_side_effects(self):
		"""Characterize: a valid invoice reference populates reference_totals/types/accounts."""
		from erpnext.accounts.doctype.sales_invoice.test_sales_invoice import create_sales_invoice

		invoice = create_sales_invoice(rate=500)
		jv = make_journal_entry("_Test Cash - _TC", "Debtors - _TC", 100, save=False)
		jv.accounts[1].party_type = "Customer"
		jv.accounts[1].party = "_Test Customer"
		jv.accounts[1].reference_type = "Sales Invoice"
		jv.accounts[1].reference_name = invoice.name
		jv.insert()
		self.assertEqual(jv.reference_totals[invoice.name], 100.0)
		self.assertEqual(jv.reference_types[invoice.name], "Sales Invoice")
		self.assertEqual(jv.reference_accounts[invoice.name], "Debtors - _TC")

	def make_jv_against_purchase_invoice(self, invoice, amount=100):
		jv = make_journal_entry("Creditors - _TC", "_Test Cash - _TC", amount, save=False)
		jv.accounts[0].party_type = "Supplier"
		jv.accounts[0].party = invoice.supplier
		jv.accounts[0].reference_type = "Purchase Invoice"
		jv.accounts[0].reference_name = invoice.name
		return jv

	def test_jv_against_purchase_invoice_respects_hold_state(self):
		"""Payment can be booked against a Purchase Invoice only while it is not on hold."""
		from erpnext.accounts.doctype.purchase_invoice.test_purchase_invoice import make_purchase_invoice

		release_date = add_days(nowdate(), 10)

		def never_held():
			return make_purchase_invoice()

		def held_until_a_future_date():
			invoice = make_purchase_invoice()
			invoice.block_invoice(hold_comment="Waiting for the goods", release_date=release_date)
			return invoice

		def held_without_a_release_date():
			invoice = make_purchase_invoice()
			invoice.block_invoice(hold_comment="Under dispute")
			return invoice

		def held_until_a_date_that_has_passed():
			invoice = held_until_a_future_date()
			frappe.db.set_value("Purchase Invoice", invoice.name, "release_date", add_days(nowdate(), -1))
			return invoice

		def unblocked_again():
			invoice = held_until_a_future_date()
			invoice.unblock_invoice()
			return invoice

		for build_invoice in (held_until_a_future_date, held_without_a_release_date):
			with self.subTest(build_invoice.__name__):
				jv = self.make_jv_against_purchase_invoice(build_invoice())
				self.assertRaisesRegex(frappe.ValidationError, "is blocked and on hold until", jv.insert)

		for build_invoice in (never_held, held_until_a_date_that_has_passed, unblocked_again):
			with self.subTest(build_invoice.__name__):
				invoice = build_invoice()
				jv = self.make_jv_against_purchase_invoice(invoice)
				jv.insert()
				self.assertEqual(jv.reference_types[invoice.name], "Purchase Invoice")

	def test_jv_against_blocked_sales_invoice_reference_is_not_checked(self):
		"""A Sales Invoice has no hold state, so the check must skip it rather than fail."""
		from erpnext.accounts.doctype.sales_invoice.test_sales_invoice import create_sales_invoice

		invoice = create_sales_invoice(rate=500)
		jv = make_journal_entry("_Test Cash - _TC", "Debtors - _TC", 100, save=False)
		jv.accounts[1].party_type = "Customer"
		jv.accounts[1].party = "_Test Customer"
		jv.accounts[1].reference_type = "Sales Invoice"
		jv.accounts[1].reference_name = invoice.name
		jv.insert()

		self.assertEqual(jv.reference_types[invoice.name], "Sales Invoice")

	def test_get_balance_places_difference_on_blank_row(self):
		"""Characterize: get_balance puts the unbalanced difference on an amountless row."""
		jv = frappe.new_doc("Journal Entry")
		jv.company = "_Test Company"
		jv.posting_date = nowdate()
		jv.append(
			"accounts",
			{
				"account": "_Test Cash - _TC",
				"debit_in_account_currency": 100,
				"debit": 100,
				"exchange_rate": 1,
			},
		)
		jv.append("accounts", {"account": "_Test Bank - _TC", "exchange_rate": 1})  # amountless row
		jv.set_total_debit_credit()
		self.assertEqual(jv.difference, 100)

		jv.get_balance()
		blank_row = jv.accounts[1]
		self.assertEqual(blank_row.credit_in_account_currency, 100)
		self.assertEqual(jv.total_debit, jv.total_credit)

	def test_get_balance_recomputes_difference_ignoring_client_value(self):
		"""get_balance computes its own difference instead of trusting a stale client-sent value."""
		jv = frappe.new_doc("Journal Entry")
		jv.company = "_Test Company"
		jv.posting_date = nowdate()
		jv.append(
			"accounts",
			{
				"account": "_Test Cash - _TC",
				"debit_in_account_currency": 100,
				"debit": 100,
				"exchange_rate": 1,
			},
		)
		jv.append("accounts", {"account": "_Test Bank - _TC", "exchange_rate": 1})
		# a stale/incorrect value as the client might send; get_balance must not rely on it
		jv.difference = 0

		jv.get_balance()
		self.assertEqual(jv.accounts[1].credit_in_account_currency, 100)
		self.assertEqual(jv.total_debit, jv.total_credit)
		self.assertEqual(jv.difference, 0)

	def test_get_outstanding_invoices_builds_write_off_rows(self):
		"""Characterize: get_outstanding_invoices adds a party row for each outstanding invoice."""
		from erpnext.accounts.doctype.sales_invoice.test_sales_invoice import create_sales_invoice

		invoice = create_sales_invoice(rate=700)
		jv = frappe.new_doc("Journal Entry")
		jv.company = "_Test Company"
		jv.posting_date = nowdate()
		jv.voucher_type = "Write Off Entry"
		jv.write_off_based_on = "Accounts Receivable"
		jv.write_off_amount = 1000
		jv.get_outstanding_invoices()

		invoice_rows = [row for row in jv.accounts if row.reference_name == invoice.name]
		self.assertTrue(invoice_rows)
		self.assertEqual(invoice_rows[0].party_type, "Customer")
		self.assertEqual(invoice_rows[0].reference_type, "Sales Invoice")
		self.assertEqual(flt(invoice_rows[0].credit_in_account_currency), 700)

	def test_unlink_advance_entry_reference_on_cancel(self):
		"""Characterize: cancelling an advance JE against an invoice clears the row's reference."""
		from erpnext.accounts.doctype.sales_invoice.test_sales_invoice import create_sales_invoice

		invoice = create_sales_invoice(rate=700)
		jv = make_journal_entry("_Test Cash - _TC", "Debtors - _TC", 100, save=False)
		advance_row = jv.accounts[1]
		advance_row.party_type = "Customer"
		advance_row.party = "_Test Customer"
		advance_row.is_advance = "Yes"
		advance_row.reference_type = "Sales Invoice"
		advance_row.reference_name = invoice.name
		jv.submit()

		jv.cancel()
		jv.reload()
		self.assertFalse(jv.accounts[1].reference_type)
		self.assertFalse(jv.accounts[1].reference_name)

	def test_get_payment_entry_against_order_builds_advance_je(self):
		"""Characterize the mapper: an advance Bank Entry JE is built against an unbilled order."""
		from erpnext.accounts.doctype.journal_entry.mapper import get_payment_entry_against_order
		from erpnext.selling.doctype.sales_order.test_sales_order import make_sales_order

		sales_order = make_sales_order()
		je = get_payment_entry_against_order("Sales Order", sales_order.name, journal_entry=True)

		self.assertEqual(je.voucher_type, "Bank Entry")
		party_rows = [row for row in je.accounts if row.party_type == "Customer"]
		self.assertTrue(party_rows)
		self.assertEqual(party_rows[0].reference_type, "Sales Order")
		self.assertEqual(party_rows[0].reference_name, sales_order.name)
		self.assertEqual(party_rows[0].is_advance, "Yes")

	def test_make_inter_company_journal_entry_builds_linked_draft(self):
		"""Characterize the mapper: the counterpart JE carries the company and back-reference."""
		from erpnext.accounts.doctype.journal_entry.mapper import make_inter_company_journal_entry

		source = make_journal_entry("_Test Cash - _TC", "_Test Bank - _TC", 100, submit=True)
		result = make_inter_company_journal_entry(
			source.name, "Inter Company Journal Entry", "_Test Company 1"
		)

		self.assertEqual(result.get("voucher_type"), "Inter Company Journal Entry")
		self.assertEqual(result.get("company"), "_Test Company 1")
		self.assertEqual(result.get("inter_company_journal_entry_reference"), source.name)


def make_journal_entry(
	account1,
	account2,
	amount,
	cost_center=None,
	posting_date=None,
	exchange_rate=1,
	save=True,
	submit=False,
	project=None,
	company=None,
):
	if not cost_center:
		cost_center = "_Test Cost Center - _TC"

	jv = frappe.new_doc("Journal Entry")
	jv.posting_date = posting_date or nowdate()
	jv.company = company or "_Test Company"
	jv.remark = "test"
	jv.multi_currency = 1
	jv.set(
		"accounts",
		[
			{
				"account": account1,
				"cost_center": cost_center,
				"project": project,
				"debit_in_account_currency": amount if amount > 0 else 0,
				"credit_in_account_currency": abs(amount) if amount < 0 else 0,
				"exchange_rate": exchange_rate,
			},
			{
				"account": account2,
				"cost_center": cost_center,
				"project": project,
				"credit_in_account_currency": amount if amount > 0 else 0,
				"debit_in_account_currency": abs(amount) if amount < 0 else 0,
				"exchange_rate": exchange_rate,
			},
		],
	)
	if save or submit:
		jv.insert()

		if submit:
			jv.submit()

	return jv
