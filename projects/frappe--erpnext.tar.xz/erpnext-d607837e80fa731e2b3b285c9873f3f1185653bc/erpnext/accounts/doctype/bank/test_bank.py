# Copyright (c) 2018, Frappe Technologies Pvt. Ltd. and Contributors
# See license.txt

from erpnext.tests.utils import ERPNextTestSuite


class TestBank(ERPNextTestSuite):
	pass
