# Copyright (c) 2020, Frappe Technologies Pvt. Ltd. and Contributors
# See license.txt
# import frappe

from erpnext.tests.utils import ERPNextTestSuite


class TestBankAccountType(ERPNextTestSuite):
	pass
