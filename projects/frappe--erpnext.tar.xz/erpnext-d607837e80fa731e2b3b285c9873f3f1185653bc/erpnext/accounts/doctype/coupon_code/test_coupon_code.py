# Copyright (c) 2018, Frappe Technologies Pvt. Ltd. and Contributors
# See license.txt

import frappe

from erpnext.selling.doctype.sales_order.test_sales_order import make_sales_order
from erpnext.tests.utils import ERPNextTestSuite


def test_create_test_data():
	frappe.set_user("Administrator")
	# create test item
	if not frappe.db.exists("Item", "_Test Tesla Car"):
		item = frappe.get_doc(
			{
				"description": "_Test Tesla Car",
				"doctype": "Item",
				"has_batch_no": 0,
				"has_serial_no": 0,
				"inspection_required": 0,
				"is_stock_item": 1,
				"opening_stock": 100,
				"is_sub_contracted_item": 0,
				"item_code": "_Test Tesla Car",
				"item_group": "_Test Item Group",
				"item_name": "_Test Tesla Car",
				"apply_warehouse_wise_reorder_level": 0,
				"warehouse": "Stores - _TC",
				"valuation_rate": 5000,
				"standard_rate": 5000,
				"item_defaults": [
					{
						"company": "_Test Company",
						"default_warehouse": "Stores - _TC",
						"default_price_list": "_Test Price List",
						"expense_account": "Cost of Goods Sold - _TC",
						"buying_cost_center": "Main - _TC",
						"selling_cost_center": "Main - _TC",
						"income_account": "Sales - _TC",
					}
				],
			}
		)
		item.insert()
	# create test item price
	item_price = frappe.get_list(
		"Item Price",
		filters={"item_code": "_Test Tesla Car", "price_list": "_Test Price List"},
		fields=["name"],
	)
	if len(item_price) == 0:
		item_price = frappe.get_doc(
			{
				"doctype": "Item Price",
				"item_code": "_Test Tesla Car",
				"price_list": "_Test Price List",
				"price_list_rate": 5000,
			}
		)
		item_price.insert()
	# create test item pricing rule
	if not frappe.db.exists("Pricing Rule", {"title": "_Test Pricing Rule for _Test Item"}):
		item_pricing_rule = frappe.get_doc(
			{
				"doctype": "Pricing Rule",
				"title": "_Test Pricing Rule for _Test Item",
				"apply_on": "Item Code",
				"items": [{"item_code": "_Test Tesla Car"}],
				"warehouse": "Stores - _TC",
				"coupon_code_based": 1,
				"selling": 1,
				"rate_or_discount": "Discount Percentage",
				"discount_percentage": 30,
				"company": "_Test Company",
				"currency": "INR",
				"for_price_list": "_Test Price List",
			}
		)
		item_pricing_rule.insert()
	# create test item sales partner
	if not frappe.db.exists("Sales Partner", "_Test Coupon Partner"):
		sales_partner = frappe.get_doc(
			{
				"doctype": "Sales Partner",
				"partner_name": "_Test Coupon Partner",
				"commission_rate": 2,
				"referral_code": "COPART",
				"territory": "All Territories",
			}
		)
		sales_partner.insert()
	# create test item coupon code
	if not frappe.db.exists("Coupon Code", "SAVE30"):
		pricing_rule = frappe.db.get_value(
			"Pricing Rule", {"title": "_Test Pricing Rule for _Test Item"}, ["name"]
		)
		coupon_code = frappe.get_doc(
			{
				"doctype": "Coupon Code",
				"coupon_name": "SAVE30",
				"coupon_code": "SAVE30",
				"pricing_rule": pricing_rule,
				"valid_from": "2014-01-01",
				"maximum_use": 1,
				"used": 0,
			}
		)
		coupon_code.insert()


class TestCouponCode(ERPNextTestSuite):
	def setUp(self):
		test_create_test_data()

	def test_disabled_pricing_rule_validation(self):
		coupon = frappe.get_doc("Coupon Code", "SAVE30")
		rule = frappe.get_doc("Pricing Rule", coupon.pricing_rule)
		rule.disable = 1
		rule.save()

		with self.subTest("new coupon cannot select a disabled rule"):
			new_coupon = frappe.copy_doc(coupon)
			new_coupon.coupon_name = "Festival Savings"
			new_coupon.coupon_code = "FESTSAVE"
			with self.assertRaisesRegex(frappe.ValidationError, "is disabled"):
				new_coupon.insert()

		with self.subTest("existing coupon can retain a disabled rule"):
			coupon.description = "Offer paused"
			coupon.save()
			coupon.reload()
			self.assertEqual(coupon.description, "Offer paused")
			self.assertEqual(coupon.pricing_rule, rule.name)

		with self.subTest("existing coupon cannot switch to a disabled rule"):
			disabled_rule = frappe.copy_doc(rule)
			disabled_rule.insert()
			coupon.reload()
			coupon.pricing_rule = disabled_rule.name
			with self.assertRaisesRegex(frappe.ValidationError, "is disabled"):
				coupon.save()
			coupon.reload()
			self.assertEqual(coupon.pricing_rule, rule.name)

	def test_cannot_save_coupon_with_reversed_validity_dates(self):
		coupon = frappe.get_doc("Coupon Code", "SAVE30")
		coupon.valid_from = "2026-09-17"
		coupon.valid_upto = "2026-09-02"
		with self.assertRaises(frappe.exceptions.InvalidDates):
			coupon.save()

	def test_sales_order_with_coupon_code(self):
		frappe.db.set_value("Coupon Code", "SAVE30", "used", 0)

		so = make_sales_order(
			company="_Test Company",
			warehouse="Stores - _TC",
			customer="_Test Customer",
			selling_price_list="_Test Price List",
			item_code="_Test Tesla Car",
			rate=5000,
			qty=1,
			do_not_save=True,
		)

		self.assertEqual(so.items[0].rate, 5000)

		so.coupon_code = "SAVE30"
		so.sales_partner = "_Test Coupon Partner"
		so.save()

		# check item price after coupon code is applied
		self.assertEqual(so.items[0].rate, 3500)

		so.submit()
		self.assertEqual(frappe.db.get_value("Coupon Code", "SAVE30", "used"), 1)

	def test_coupon_without_max_use(self):
		from erpnext.accounts.doctype.pricing_rule.utils import (
			update_coupon_code_count,
			validate_coupon_code,
		)

		coupon = frappe.get_doc(
			{
				"doctype": "Coupon Code",
				"coupon_name": "_Test Coupon Without Max Use",
				"coupon_code": "TESTUNLIMITED",
				"from_external_ecomm_platform": 1,  # avoids requirement for pricing rule
				"valid_from": frappe.utils.nowdate(),
				"maximum_use": 0,
				"used": 0,
			}
		)
		coupon.insert(ignore_permissions=True)

		# Validate initial state
		self.assertEqual(coupon.used, 0)
		self.assertEqual(coupon.maximum_use, 0)

		# Use coupon multiple times
		for _ in range(5):
			validate_coupon_code(coupon.name)
			update_coupon_code_count(coupon.name, "used")
			coupon.reload()

		# Check that the coupon is still valid and usage count increased
		self.assertEqual(coupon.used, 5)
		validate_coupon_code(coupon.name)  # This should not raise an error

		# Clean up
		coupon.delete()

	def test_validate_coupon_code_rejections(self):
		from frappe.utils import add_days, nowdate

		from erpnext.accounts.doctype.pricing_rule.utils import validate_coupon_code

		pricing_rule = frappe.db.get_value("Pricing Rule", {"title": "_Test Pricing Rule for _Test Item"})

		def make_coupon(name, **kwargs):
			frappe.delete_doc_if_exists("Coupon Code", name)
			return frappe.get_doc(
				{
					"doctype": "Coupon Code",
					"coupon_name": name,
					"coupon_code": name,
					"coupon_type": "Promotional",
					"pricing_rule": pricing_rule,
					**kwargs,
				}
			).insert(ignore_permissions=True)

		with self.subTest("validity not yet started"):
			make_coupon("_Test Coupon Future", valid_from=add_days(nowdate(), 5))
			self.assertRaises(frappe.ValidationError, validate_coupon_code, "_Test Coupon Future")

		with self.subTest("validity expired"):
			make_coupon("_Test Coupon Expired", valid_upto=add_days(nowdate(), -5))
			self.assertRaises(frappe.ValidationError, validate_coupon_code, "_Test Coupon Expired")

		with self.subTest("maximum use exhausted"):
			make_coupon("_Test Coupon Exhausted", maximum_use=2, used=2)
			self.assertRaises(frappe.ValidationError, validate_coupon_code, "_Test Coupon Exhausted")

		with self.subTest("valid coupon passes"):
			make_coupon("_Test Coupon Valid", maximum_use=5, used=1, valid_upto=add_days(nowdate(), 5))
			validate_coupon_code("_Test Coupon Valid")  # no raise

	def test_update_coupon_code_count_cancel_and_exhaust(self):
		from erpnext.accounts.doctype.pricing_rule.utils import update_coupon_code_count

		pricing_rule = frappe.db.get_value("Pricing Rule", {"title": "_Test Pricing Rule for _Test Item"})
		frappe.delete_doc_if_exists("Coupon Code", "_Test Coupon Count")
		frappe.get_doc(
			{
				"doctype": "Coupon Code",
				"coupon_name": "_Test Coupon Count",
				"coupon_code": "_Test Coupon Count",
				"coupon_type": "Promotional",
				"pricing_rule": pricing_rule,
				"maximum_use": 2,
				"used": 1,
			}
		).insert(ignore_permissions=True)

		# cancelling a transaction releases one use
		update_coupon_code_count("_Test Coupon Count", "cancelled")
		self.assertEqual(frappe.db.get_value("Coupon Code", "_Test Coupon Count", "used"), 0)

		# using up to the maximum is allowed, beyond it is rejected
		update_coupon_code_count("_Test Coupon Count", "used")
		update_coupon_code_count("_Test Coupon Count", "used")
		self.assertEqual(frappe.db.get_value("Coupon Code", "_Test Coupon Count", "used"), 2)
		self.assertRaises(frappe.ValidationError, update_coupon_code_count, "_Test Coupon Count", "used")
