// Copyright (c) 2023, Frappe Technologies Pvt. Ltd. and contributors
// For license information, please see license.txt

frappe.ui.form.on("Account Closing Balance", {
	refresh(frm) {
		frm.page.btn_secondary.hide();
	},
});
