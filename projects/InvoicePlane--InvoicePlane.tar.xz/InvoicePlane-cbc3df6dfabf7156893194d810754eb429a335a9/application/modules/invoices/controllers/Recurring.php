<?php

if ( ! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/*
 * InvoicePlane
 *
 * @author      InvoicePlane Developers & Contributors
 * @copyright   Copyright (c) 2012 - 2018 InvoicePlane.com
 * @license     https://invoiceplane.com/license.txt
 * @link        https://invoiceplane.com
 */

#[AllowDynamicProperties]
class Recurring extends Admin_Controller
{
    /**
     * Recurring constructor.
     */
    public function __construct()
    {
        parent::__construct();

        $this->load->model('mdl_invoices_recurring');
    }

    /**
     * @param int $page
     */
    public function index($page = 0)
    {
        $this->mdl_invoices_recurring->paginate(site_url('invoices/recurring'), $page);
        $recurring_invoices = $this->mdl_invoices_recurring->result();

        $this->layout->set([
            'filter_display'     => true,
            'filter_placeholder' => trans('filter_invoices_recuring'),
            'filter_method'      => 'filter_invoices_recuring',
            'recur_frequencies'  => $this->mdl_invoices_recurring->recur_frequencies,
            'recurring_invoices' => $recurring_invoices,
        ]);
        $this->layout->buffer('content', 'invoices/index_recurring');
        $this->layout->render();
    }

    /**
     * @param $invoice_recurring_id
     */
    public function stop($invoice_recurring_id)
    {
        if ( ! $this->ensure_valid_post_request('invoices/recurring/index')) {
            return;
        }

        $this->mdl_invoices_recurring->stop($invoice_recurring_id);
        redirect('invoices/recurring/index');
    }

    /**
     * @param $invoice_recurring_id
     */
    public function delete($invoice_recurring_id)
    {
        if ( ! $this->ensure_valid_post_request('invoices/recurring/index')) {
            return;
        }

        $this->mdl_invoices_recurring->delete($invoice_recurring_id);
        redirect('invoices/recurring/index');
    }
}
