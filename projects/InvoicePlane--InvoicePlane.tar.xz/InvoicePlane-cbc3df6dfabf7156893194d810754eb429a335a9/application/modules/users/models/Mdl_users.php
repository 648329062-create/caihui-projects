<?php

if ( ! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/*
 * InvoicePlane
 *
 * @author      InvoicePlane Developers & Contributors
 * @copyright   Copyright (c) 2012 - 2018 InvoicePlane.com
 * @license     https://invoiceplane.com/license.txt
 * @link        https://invoiceplane.com
 */

#[AllowDynamicProperties]
class Mdl_Users extends Response_Model
{
    /**
     * Fields that must never be written from raw POST data regardless of
     * validation rules. Controllers that legitimately need to set these
     * must build and pass their own $db_array to save().
     */
    private const PROTECTED_FIELDS = ['user_type', 'user_active', 'user_psalt'];

    /**
     * The bootstrap root account. Only this account may edit its own record;
     * a peer administrator must not be able to alter any of its attributes
     * (password, email, role type, active flag, or otherwise).
     */
    public const PRIMARY_ADMINISTRATOR_ID = 1;

    /**
     * Identity- and privilege-bearing fields the primary administrator's record
     * must never receive from a non-root session, regardless of code path.
     */
    private const PRIMARY_ADMIN_LOCKED_FIELDS = ['user_type', 'user_active', 'user_psalt', 'user_email', 'user_password'];

    public $table = 'ip_users';

    public $primary_key = 'ip_users.user_id';

    public $date_created_field = 'user_date_created';

    public $date_modified_field = 'user_date_modified';

    /**
     * @return array
     */
    public function user_types()
    {
        return [
            '1' => trans('administrator'),
            '2' => trans('guest_read_only'),
        ];
    }

    /**
     * Whether the given user id identifies the primary administrator (user_id = 1).
     *
     * Accepts int or string ids from routes and sessions; canonicalizes through
     * (int) so that "1", "01" and "1abc" all resolve to the root account.
     *
     * @param int|string|null $user_id
     */
    public static function is_primary_administrator($user_id): bool
    {
        return $user_id !== null && $user_id !== '' && (int) $user_id === self::PRIMARY_ADMINISTRATOR_ID;
    }

    public function default_select(): void
    {
        $this->db->select('SQL_CALC_FOUND_ROWS ip_users.*', false);
    }

    public function default_order_by(): void
    {
        $this->db->order_by('ip_users.user_name');
    }

    /**
     * @return array
     */
    public function validation_rules()
    {
        return [
            'user_type' => [
                'field' => 'user_type',
                'label' => trans('user_type'),
                'rules' => 'required',
            ],
            'user_email' => [
                'field' => 'user_email',
                'label' => trans('email'),
                'rules' => 'required|valid_email|is_unique[ip_users.user_email]',
            ],
            'user_name' => [
                'field' => 'user_name',
                'label' => trans('name'),
                'rules' => 'required',
            ],
            'user_password' => [
                'field' => 'user_password',
                'label' => trans('password'),
                'rules' => 'required|min_length[8]',
            ],
            'user_passwordv' => [
                'field' => 'user_passwordv',
                'label' => trans('verify_password'),
                'rules' => 'required|matches[user_password]',
            ],
            'user_language' => [
                'field' => 'user_language',
                'label' => trans('language'),
                'rules' => 'required',
            ],
            'user_company' => [
                'field' => 'user_company',
            ],
            'user_address_1' => [
                'field' => 'user_address_1',
            ],
            'user_address_2' => [
                'field' => 'user_address_2',
            ],
            'user_city' => [
                'field' => 'user_city',
            ],
            'user_state' => [
                'field' => 'user_state',
            ],
            'user_zip' => [
                'field' => 'user_zip',
            ],
            'user_country' => [
                'field' => 'user_country',
                'label' => trans('country'),
            ],
            'user_phone' => [
                'field' => 'user_phone',
            ],
            'user_fax' => [
                'field' => 'user_fax',
            ],
            'user_mobile' => [
                'field' => 'user_mobile',
            ],
            'user_web' => [
                'field' => 'user_web',
            ],
            'user_vat_id' => [
                'field' => 'user_vat_id',
            ],
            'user_tax_code' => [
                'field' => 'user_tax_code',
            ],
            'user_invoicing_contact' => [
                'field' => 'user_invoicing_contact',
                'rules' => 'trim',
            ],
            'user_bank' => [
                'field' => 'user_bank',
                'rules' => 'trim',
            ],
            'user_iban' => [
                'field' => 'user_iban',
            ],
            'user_bic' => [
                'field' => 'user_bic',
                'rules' => 'trim|xss_clean',
            ],
            'user_remittance_text' => [
                'field' => 'user_remittance',
                'rules' => 'trim|xss_clean',
            ],
            // SUMEX
            'user_subscribernumber' => [
                'field' => 'user_subscribernumber',
            ],
            'user_gln' => [
                'field' => 'user_gln',
            ],
            'user_rcc' => [
                'field' => 'user_rcc',
            ],
        ];
    }

    /**
     * @param int $amount
     *
     * @return mixed
     */
    public function get_latest($amount = 20)
    {
        return $this->mdl_users
            ->where('user_active', 1)
            ->order_by('user_id', 'DESC')
            ->limit($amount)
            ->get()
            ->result();
    }

    /**
     * @return array
     */
    public function validation_rules_existing()
    {
        return [
            'user_type' => [
                'field' => 'user_type',
                'label' => trans('user_type'),
                'rules' => 'required',
            ],
            'user_email' => [
                'field' => 'user_email',
                'label' => trans('email'),
                'rules' => 'required|valid_email',
            ],
            'user_name' => [
                'field' => 'user_name',
                'label' => trans('name'),
                'rules' => 'required',
            ],
            'user_language' => [
                'field' => 'user_language',
                'label' => trans('language'),
                'rules' => 'required',
            ],
            'user_company' => [
                'field' => 'user_company',
            ],
            'user_address_1' => [
                'field' => 'user_address_1',
            ],
            'user_address_2' => [
                'field' => 'user_address_2',
            ],
            'user_city' => [
                'field' => 'user_city',
            ],
            'user_state' => [
                'field' => 'user_state',
            ],
            'user_zip' => [
                'field' => 'user_zip',
            ],
            'user_country' => [
                'field' => 'user_country',
                'label' => trans('country'),
            ],
            'user_phone' => [
                'field' => 'user_phone',
            ],
            'user_fax' => [
                'field' => 'user_fax',
            ],
            'user_mobile' => [
                'field' => 'user_mobile',
            ],
            'user_web' => [
                'field' => 'user_web',
            ],
            'user_vat_id' => [
                'field' => 'user_vat_id',
            ],
            'user_tax_code' => [
                'field' => 'user_tax_code',
            ],
            'user_invoicing_contact' => [
                'field' => 'user_invoicing_contact',
            ],
            'user_bank' => [
                'field' => 'user_bank',
            ],
            'user_iban' => [
                'field' => 'user_iban',
            ],
            'user_bic' => [
                'field' => 'user_bic',
            ],
            'user_remittance_text' => [
                'field' => 'user_remittance',
            ],
            // SUMEX
            'user_subscribernumber' => [
                'field' => 'user_subscribernumber',
            ],
            'user_gln' => [
                'field' => 'user_gln',
            ],
            'user_rcc' => [
                'field' => 'user_rcc',
            ],
        ];
    }

    /**
     * @return array
     */
    public function validation_rules_change_password()
    {
        return [
            'user_password' => [
                'field' => 'user_password',
                'label' => trans('password'),
                'rules' => 'required',
            ],
            'user_passwordv' => [
                'field' => 'user_passwordv',
                'label' => trans('verify_password'),
                'rules' => 'required|matches[user_password]',
            ],
        ];
    }

    /**
     * @return array
     */
    public function db_array()
    {
        $db_array = parent::db_array();

        // Strip privilege-escalation fields from POST-sourced data.
        foreach (self::PROTECTED_FIELDS as $field) {
            unset($db_array[$field]);
        }

        if (isset($db_array['user_password'])) {
            unset($db_array['user_passwordv']);

            $this->load->library('crypt');

            $user_psalt = $this->crypt->salt();

            $db_array['user_psalt']    = $user_psalt;
            $db_array['user_password'] = $this->crypt->generate_password($db_array['user_password'], $user_psalt);
        }

        return $db_array;
    }

    /**
     * @param $user_id
     * @param $password
     */
    public function save_change_password($user_id, $password): void
    {
        $this->load->library('crypt');

        $user_psalt    = $this->crypt->salt();
        $user_password = $this->crypt->generate_password($password, $user_psalt);

        $db_array = [
            'user_psalt'    => $user_psalt,
            'user_password' => $user_password,
        ];

        $this->db->where('user_id', $user_id);
        $this->db->update('ip_users', $db_array);

        $this->session->set_flashdata('alert_success', trans('password_changed'));
    }

    /**
     * @return int|null
     */
    public function save($id = null, $db_array = null)
    {
        // Defense-in-depth for CWE-639 / CWE-269: the primary administrator's
        // identity and privilege attributes must never be mutated by a non-root
        // session, no matter which code path reaches save(). Users::form()
        // already rejects such requests with a 403; this backstop covers any
        // other caller that hands us a privilege-bearing $db_array for user_id 1.
        if (is_array($db_array)
            && self::is_primary_administrator($id)
            && ! self::is_primary_administrator($this->session->userdata('user_id'))
        ) {
            foreach (self::PRIMARY_ADMIN_LOCKED_FIELDS as $field) {
                unset($db_array[$field]);
            }
        }

        $id = parent::save($id, $db_array);

        if ($user_clients = $this->session->userdata('user_clients')) {
            $this->load->model('users/mdl_user_clients');

            foreach ($user_clients as $user_client) {
                $this->mdl_user_clients->save(null, ['user_id' => $id, 'client_id' => $user_client]);
            }

            $this->session->unset_userdata('user_clients');
        }

        return $id;
    }

    /**
     * @param int $id
     */
    public function delete($id): void
    {
        parent::delete($id);

        $this->load->helper('orphan');
        delete_orphans();
    }
}
