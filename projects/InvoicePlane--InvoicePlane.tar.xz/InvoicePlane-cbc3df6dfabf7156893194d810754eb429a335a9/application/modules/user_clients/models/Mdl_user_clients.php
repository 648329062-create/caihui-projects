<?php

if ( ! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/*
 * InvoicePlane
 *
 * @author      InvoicePlane Developers & Contributors
 * @copyright   Copyright (c) 2012 - 2018 InvoicePlane.com
 * @license     https://invoiceplane.com/license.txt
 * @link        https://invoiceplane.com
 */

#[AllowDynamicProperties]
class Mdl_User_Clients extends MY_Model
{
    public $table = 'ip_user_clients';

    public $primary_key = 'ip_user_clients.user_client_id';

    public function default_select()
    {
        $this->db->select('ip_user_clients.*, ip_users.user_name, ip_clients.client_name, ip_clients.client_surname');
    }

    public function default_join()
    {
        $this->db->join('ip_users', 'ip_users.user_id = ip_user_clients.user_id');
        $this->db->join('ip_clients', 'ip_clients.client_id = ip_user_clients.client_id');
    }

    public function default_order_by()
    {
        $this->db->order_by('ip_clients.client_name', 'ACS');
    }

    /**
     * @return array
     */
    public function validation_rules()
    {
        return [
            'user_id' => [
                'field' => 'user_id',
                'label' => trans('user'),
                'rules' => 'required',
            ],
            'client_id' => [
                'field' => 'client_id',
                'label' => trans('client'),
                'rules' => 'required',
            ],
        ];
    }

    /**
     * @param $user_id
     *
     * @return $this
     */
    public function assigned_to($user_id)
    {
        $this->filter_where('ip_user_clients.user_id', $user_id);

        return $this;
    }

    /**
     * @param array $users_id
     */
    public function set_all_clients_user($users_id)
    {
        $this->load->model('clients/mdl_clients');

        $nbUsers = count($users_id);
        for ($x = 0; $x < $nbUsers; $x++) {
            $clients   = $this->mdl_clients->get_not_assigned_to_user($users_id[$x]);
            $nbClients = count($clients);
            for ($i = 0; $i < $nbClients; $i++) {
                $user_client = [
                    'user_id'   => $users_id[$x],
                    'client_id' => $clients[$i]->client_id,
                ];

                $this->db->insert('ip_user_clients', $user_client);
            }
        }
    }

    public function get_users_all_clients()
    {
        $this->load->model('users/mdl_users');
        $users = $this->mdl_users->where('user_all_clients', 1)->get()->result();

        $new_users = [];
        $nbUsers   = count($users);

        for ($i = 0; $i < $nbUsers; $i++) {
            $new_users[] = $users[$i]->user_id;
        }

        $this->set_all_clients_user($new_users);
    }

    /**
     * Check if the current user can manage (delete/edit) this user-client authorization mapping.
     *
     * Security: Prevents IDOR vulnerabilities by verifying the user can manage
     * the user_client mapping (typically only admins).
     *
     * @param int $user_client_id The user_client ID to check
     *
     * @return bool True if user can manage, false otherwise
     */
    public function can_user_manage($user_client_id)
    {
        $CI = & get_instance();

        // Normalize to integer to prevent type juggling
        $user_type      = (int) $CI->session->userdata('user_type');
        $user_client_id = (int) $user_client_id;

        // Only admin users (type 1) can manage user-client mappings
        if ($user_type === 1) {
            return true;
        }

        // Non-admin users cannot manage authorization mappings
        return false;
    }
}
