<?php

if ( ! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/*
 * InvoicePlane
 *
 * @author      InvoicePlane Developers & Contributors
 * @copyright   Copyright (c) 2012 - 2018 InvoicePlane.com
 * @license     https://invoiceplane.com/license.txt
 * @link        https://invoiceplane.com
 */

#[AllowDynamicProperties]
class View extends Base_Controller
{
    /**
     * Constructor - load file security helper for validation.
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('file_security');
    }

    /**
     * @param $invoice_url_key
     */
    public function invoice($invoice_url_key = '')
    {
        if ( ! $invoice_url_key) {
            show_404();
        }

        $this->load->model('invoices/mdl_invoices');

        $invoice = $this->mdl_invoices->guest_visible()->where('invoice_url_key', $invoice_url_key)->get();

        if ($invoice->num_rows() != 1) {
            show_404();
        }

        $this->load->model(
            [
                'invoices/mdl_items',
                'invoices/mdl_invoice_tax_rates',
                'payment_methods/mdl_payment_methods',
                'custom_fields/mdl_custom_fields',
                'upload/mdl_uploads',
            ]
        );
        $this->load->helper('template');
        $this->load->helper('file_security');

        $invoice = $invoice->row();

        if ($this->session->userdata('user_type') != 1 && $invoice->invoice_status_id == 2) {
            $this->mdl_invoices->mark_viewed($invoice->invoice_id);
        }

        $payment_method = $this->mdl_payment_methods->where('payment_method_id', $invoice->payment_method)->get()->row();
        if ($invoice->payment_method == 0) {
            $payment_method = null;
        }

        // Get all custom fields
        $custom_fields = [
            'invoice' => $this->mdl_custom_fields->get_values_for_fields('mdl_invoice_custom', $invoice->invoice_id),
            'client'  => $this->mdl_custom_fields->get_values_for_fields('mdl_client_custom', $invoice->client_id),
            'user'    => $this->mdl_custom_fields->get_values_for_fields('mdl_user_custom', $invoice->user_id),
        ];

        // Attachments
        $attachments = $this->get_attachments($invoice_url_key);

        // Security: Validate strtotime() result before comparison to avoid type juggling
        $invoice_due_timestamp = strtotime($invoice->invoice_date_due);
        $is_overdue            = ($invoice->invoice_balance > 0
            && $invoice_due_timestamp !== false
            && $invoice_due_timestamp < time());

        $data = [
            'invoice'            => $invoice,
            'items'              => $this->mdl_items->where('invoice_id', $invoice->invoice_id)->get()->result(),
            'invoice_tax_rates'  => $this->mdl_invoice_tax_rates->where('invoice_id', $invoice->invoice_id)->get()->result(),
            'invoice_url_key'    => $invoice_url_key,
            'flash_message'      => $this->session->flashdata('flash_message'),
            'payment_method'     => $payment_method,
            'is_overdue'         => $is_overdue,
            'attachments'        => $attachments,
            'custom_fields'      => $custom_fields,
            'legacy_calculation' => config_item('legacy_calculation'),
        ];

        $data['show_item_discounts'] = $this->has_discounts($data['items']);

        // Security: Validate and get template path with defense-in-depth
        $requested_template = get_setting('public_invoice_template');
        $template_info      = get_validated_template_path($requested_template, 'invoice', 'public', 'InvoicePlane_Web');

        render_template_view($template_info['path'], $data);
    }

    /**
     * @param      $invoice_url_key
     * @param bool $stream
     */
    public function generate_invoice_pdf($invoice_url_key, $stream = true, $invoice_template = null)
    {
        $this->load->model('invoices/mdl_invoices');

        $invoice = $this->mdl_invoices->guest_visible()->where('invoice_url_key', $invoice_url_key)->get();

        if ($invoice->num_rows() == 1) {
            $invoice = $invoice->row();

            // Security: Validate PDF template to prevent LFI
            $this->load->helper('template');
            if ($invoice_template) {
                $invoice_template = validate_pdf_template($invoice_template, 'invoice');
            } else {
                $invoice_template = select_pdf_invoice_template($invoice);
            }

            $this->load->helper('pdf');

            generate_invoice_pdf($invoice->invoice_id, $stream, $invoice_template, 1);
        }
    }

    /**
     * @param      $invoice_url_key
     * @param bool $stream
     */
    public function generate_sumex_pdf($invoice_url_key, $stream = true, $invoice_template = null)
    {
        $this->load->model('invoices/mdl_invoices');

        $invoice = $this->mdl_invoices->guest_visible()->where('invoice_url_key', $invoice_url_key)->get();

        if ($invoice->num_rows() == 1) {
            $invoice = $invoice->row();

            if ($invoice->sumex_id == null) {
                show_404();
            }

            $this->load->helper(['pdf', 'template']);

            // Security: Validate PDF template to prevent LFI
            if ($invoice_template) {
                $invoice_template = validate_pdf_template($invoice_template, 'invoice');
            }

            generate_invoice_sumex($invoice->invoice_id, $stream, $invoice_template, true);
        }
    }

    /**
     * @param $quote_url_key
     */
    public function quote($quote_url_key = '')
    {
        if ( ! $quote_url_key) {
            show_404();
        }

        $this->load->model('quotes/mdl_quotes');

        $quote = $this->mdl_quotes->guest_visible()->where('quote_url_key', $quote_url_key)->get();

        if ($quote->num_rows() != 1) {
            show_404();
        }

        $this->load->model('quotes/mdl_quote_items');
        $this->load->model('quotes/mdl_quote_tax_rates');
        $this->load->model('custom_fields/mdl_custom_fields');
        $this->load->helper('template');

        $quote = $quote->row();

        if ($this->session->userdata('user_type') != 1 && $quote->quote_status_id == 2) {
            $this->mdl_quotes->mark_viewed($quote->quote_id);
        }

        // Get all custom fields
        $custom_fields = [
            'quote'  => $this->mdl_custom_fields->get_values_for_fields('mdl_quote_custom', $quote->quote_id),
            'client' => $this->mdl_custom_fields->get_values_for_fields('mdl_client_custom', $quote->client_id),
            'user'   => $this->mdl_custom_fields->get_values_for_fields('mdl_user_custom', $quote->user_id),
        ];

        // Attachments
        $attachments = $this->get_attachments($quote_url_key);

        // Security: Validate strtotime() result before comparison to avoid type juggling
        $quote_expires_timestamp = strtotime($quote->quote_date_expires);
        $is_expired              = ($quote_expires_timestamp !== false && $quote_expires_timestamp < time());

        $data = [
            'quote'              => $quote,
            'items'              => $this->mdl_quote_items->where('quote_id', $quote->quote_id)->get()->result(),
            'quote_tax_rates'    => $this->mdl_quote_tax_rates->where('quote_id', $quote->quote_id)->get()->result(),
            'quote_url_key'      => $quote_url_key,
            'flash_message'      => $this->session->flashdata('flash_message'),
            'is_expired'         => $is_expired,
            'attachments'        => $attachments,
            'custom_fields'      => $custom_fields,
            'legacy_calculation' => config_item('legacy_calculation'),
        ];
        $data['show_item_discounts'] = $this->has_discounts($data['items']);

        // Security: Validate and get template path with defense-in-depth
        $this->load->helper('template');
        $requested_template = get_setting('public_quote_template');
        $template_info      = get_validated_template_path($requested_template, 'quote', 'public', 'InvoicePlane_Web');

        render_template_view($template_info['path'], $data);
    }

    /**
     * @param      $quote_url_key
     * @param bool $stream
     */
    public function generate_quote_pdf($quote_url_key, $stream = true, $quote_template = null)
    {
        $this->load->model('quotes/mdl_quotes');

        $quote = $this->mdl_quotes->guest_visible()->where('quote_url_key', $quote_url_key)->get()->row();

        if ( ! $quote) {
            show_404();
        }

        // Security: Validate PDF template to prevent LFI
        $this->load->helper('template');
        $quote_template = validate_pdf_template($quote_template, 'quote', 'pdf_quote_template');

        $this->load->helper('pdf');

        generate_quote_pdf($quote->quote_id, $stream, $quote_template);
    }

    /**
     * @param $quote_url_key
     */
    public function approve_quote(string $quote_url_key)
    {
        // Require POST so CodeIgniter's CSRF token validation is enforced
        if ($this->input->method() !== 'post') {
            show_404();
        }

        $this->load->model('quotes/mdl_quotes');
        $quote = $this->validate_guest_quote_access($quote_url_key);

        $this->load->helper('mailer');

        $this->mdl_quotes->approve_quote_by_key($quote_url_key);

        // Only send email if the update actually changed the quote status
        if ($this->db->affected_rows() > 0) {
            email_quote_status($quote->quote_id, 'approved');
        }

        redirect('guest/view/quote/' . $quote_url_key);
    }

    /**
     * @param $quote_url_key
     */
    public function reject_quote(string $quote_url_key)
    {
        // Require POST so CodeIgniter's CSRF token validation is enforced
        if ($this->input->method() !== 'post') {
            show_404();
        }

        $this->load->model('quotes/mdl_quotes');
        $quote = $this->validate_guest_quote_access($quote_url_key);

        $this->load->helper('mailer');

        $this->mdl_quotes->reject_quote_by_key($quote_url_key);

        // Only send email if the update actually changed the quote status
        if ($this->db->affected_rows() > 0) {
            email_quote_status($quote->quote_id, 'rejected');
        }

        redirect('guest/view/quote/' . $quote_url_key);
    }

    /**
     * Validate guest user has access to a quote by URL key
     * Returns the quote object if valid, or shows error/404.
     *
     * @param string $quote_url_key The quote URL key
     *
     * @return object The quote object
     */
    private function validate_guest_quote_access(string $quote_url_key): object
    {
        // Require POST request to prevent CSRF attacks
        if ($this->input->method() !== 'post') {
            show_404();
        }

        // Require authentication as a guest user
        if ( ! $this->session->userdata('user_id') || (int) $this->session->userdata('user_type') !== 2) {
            show_error(trans('guest_account_denied'), 403);
        }

        $this->load->model('quotes/mdl_quotes');
        $this->load->model('user_clients/mdl_user_clients');

        // Get guest user's assigned clients
        $user_clients_result = $this->mdl_user_clients->assigned_to($this->session->userdata('user_id'))->get()->result();
        $user_clients        = [];
        foreach ($user_clients_result as $user_client) {
            $user_clients[$user_client->client_id] = $user_client->client_id;
        }

        if (empty($user_clients)) {
            show_error(trans('guest_account_denied'), 403);
        }

        // Verify quote belongs to one of the guest user's assigned clients and is open (status 2-3)
        $quote = $this->mdl_quotes->is_open()
            ->where('ip_quotes.quote_url_key', $quote_url_key)
            ->where_in('ip_quotes.client_id', $user_clients)
            ->get()->row();

        if ($quote === null) {
            show_404();
        }

        return $quote;
    }

    /**
     * Retail since 1.6.3.
     *
     * @param $url_key
     */
    private function get_attachments(string $url_key): array
    {
        // Security: Use query binding to prevent SQL injection
        $query = $this->db->query('SELECT file_name_new,file_name_original FROM ip_uploads WHERE url_key = ?', [$url_key]);

        $names = [];

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                // Security: Validate filename from database before using in file path
                $validated = validate_db_filename($row->file_name_new, UPLOADS_CFILES_FOLDER);
                if ($validated === null) {
                    // Skip invalid filenames
                    log_message('warning', sprintf(
                        'Skipping invalid filename in guest attachments for url_key=%s',
                        sanitize_for_logging($url_key)
                    ));
                    continue;
                }

                // Check file exists before getting size
                if ( ! file_exists($validated['path'])) {
                    log_message('warning', sprintf(
                        'File not found for guest attachment (hash: %s)',
                        $validated['hash']
                    ));
                    continue;
                }

                // Get file size with error handling
                $file_size = @filesize($validated['path']);
                if ($file_size === false) {
                    $error = error_get_last();
                    log_message('warning', sprintf(
                        'Failed to get file size for guest attachment (hash: %s, error: %s)',
                        $validated['hash'],
                        $error['message'] ?? 'unknown'
                    ));
                    continue;
                }

                $names[] = [
                    'name'     => html_escape($row->file_name_original),
                    'fullname' => $validated['basename'],
                    'size'     => $file_size,
                ];
            }
        }

        return $names;
    }

    /**
     * Determine if in the array of items
     * that are provided, one or more items
     * have a discount.
     *
     * @param array $items
     *
     * @return bool
     */
    private function has_discounts(array $items): bool
    {
        foreach ($items as $item) {
            if ($item->item_discount > 0) {
                return true;
            }
        }

        return false;
    }
}
