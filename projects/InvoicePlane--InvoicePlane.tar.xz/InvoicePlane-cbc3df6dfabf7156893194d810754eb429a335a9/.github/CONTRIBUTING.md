# Contributing to InvoicePlane

Thank you for considering contributing to InvoicePlane! Your support is invaluable in improving and maintaining this project. Whether you're reporting bugs, suggesting features, writing code, or helping others, your contributions are welcome.

## Table of Contents

1. [How Can I Contribute?](#how-can-i-contribute)
   - [Reporting Bugs](#reporting-bugs)
   - [Suggesting Features](#suggesting-features)
   - [Code Contributions](#code-contributions)
   - [Documentation](#documentation)
   - [Translations](#translations)
   - [Community Support](#community-support)
2. [Development Guidelines](#development-guidelines)
   - [Coding Standards](#coding-standards)
   - [Commit Messages](#commit-messages)
3. [Getting Started with Development](#getting-started-with-development)
4. [Community and Support](#community-and-support)
5. [Code of Conduct](#code-of-conduct)

---

## How Can I Contribute?

### Reporting Bugs

If you encounter a bug, please report it by [opening an issue](https://github.com/InvoicePlane/InvoicePlane/issues) and include:

- **Description:** A clear and concise description of the bug.
- **Steps to Reproduce:** Detailed steps to reproduce the issue.
- **Expected Behavior:** What you expected to happen.
- **Actual Behavior:** What actually happened.
- **Screenshots:** If applicable, add screenshots to help explain the problem.
- **Environment:** Information about your environment (e.g., operating system, browser, InvoicePlane version).

---

### Suggesting Features

To suggest a new feature, please [open an issue](https://github.com/InvoicePlane/InvoicePlane/issues) and include:

- **Feature Description:** A clear and concise description of the feature.
- **Use Case:** Explain why this feature would be useful.
- **Additional Context:** Any other context or screenshots that might help.

---

### Code Contributions

If you'd like to contribute code:

1. **Fork the Repository:** Click the "Fork" button at the top right of the [repository page](https://github.com/InvoicePlane/InvoicePlane).
2. **Clone Your Fork:**
   ```sh
   git clone https://github.com/your-username/InvoicePlane.git
   ```
3. **Create a Branch:**
   ```sh
   git checkout -b feature/your-feature-name
   ```
4. **Make Your Changes:** Implement your feature or fix.
5. **Commit Your Changes:**
   ```sh
   git commit -m "Brief description of your changes"
   ```
6. **Push to Your Fork:**
   ```sh
   git push origin feature/your-feature-name
   ```
7. **Open a Pull Request:** Go to the original repository and [open a pull request](https://github.com/InvoicePlane/InvoicePlane/pulls) from your fork.

Please ensure your code adheres to the [Development Guidelines](#development-guidelines) and includes appropriate tests.

---

### Documentation

Improving documentation is a valuable way to contribute. You can:

- **Enhance Existing Documentation:** Clarify or expand upon current documentation.
- **Create New Guides:** Write guides for new features or common tasks.
- **Fix Typos or Errors:** Correct any mistakes you find.

To contribute to the documentation:

1. **Fork the Repository:** As described above.
2. **Make Your Changes:** Edit the relevant `.md` files.
3. **Open a Pull Request:** As described above.

---

### Translations

Help make InvoicePlane accessible to a global audience by contributing translations:

- **Check Existing Translations:** See if your language is already supported.
- **Improve Translations:** Enhance existing translations for clarity and accuracy.
- **Add New Translations:** If your language isn't supported, consider adding it.

Please refer to the [TRANSLATIONS.md](TRANSLATIONS.md) for detailed instructions.

---

### Community Support

Engage with the InvoicePlane community by:

- **Answering Questions:** Assist others, Help answer questions and contribute to discussions in the [Community Forums](https://community.invoiceplane.com/).

- **[Discord Collaboration](https://discord.gg/PPzD2hTrXt)** - Join the live chat for quick discussions and collaboration.

- **[Participate in GitHub Issues](https://github.com/InvoicePlane/InvoicePlane/issues)** - Participate in bug reports, feature requests, and discussions and feature planning.

- **Helping with Troubleshooting:** Provide solutions and suggestions in support threads on the [Community Forums](https://community.invoiceplane.com/) and on [Discord](https://discord.gg/PPzD2hTrXt)

---

## Development Guidelines

### Setting Up Your Development Environment

Follow the three-phase development workflow outlined in [INSTALLATION.md](docs/INSTALLATION.md):

#### Phase 1: Prepare (Initial Setup)

1. **Clone the Repository**
   ```sh
   git clone https://github.com/InvoicePlane/InvoicePlane.git
   cd InvoicePlane
   ```

2. **Install Dependencies**
   ```sh
   composer install    # PHP dependencies
   yarn install       # JavaScript dependencies
   yarn build         # Build frontend assets
   ```

3. **Configure Application** — only needed for `docker-compose.yml` below, and only if you want
   to set it up yourself (see Phase 2):
   ```sh
   cp ipconfig.php.example ipconfig.php
   ```
   Edit `ipconfig.php` with your database and URL settings.

#### Phase 2: StartMeUp (Launch Environment)

Two Docker setups are available — see [resources/docker/README.md](../resources/docker/README.md)
for the full comparison; pick whichever matches what you're doing:

- **[`compose.yml`](../compose.yml)** — self-contained, one command, good for quickly spinning
  up InvoicePlane to test something.
- **[`docker-compose.yml`](../docker-compose.yml)** — separated `php`/`nginx`/`db`/`phpmyadmin`
  services that bind-mount your working tree, so PHP/frontend edits are reflected immediately
  without a rebuild. **This is what you want for active development.**

```sh
docker compose -f docker-compose.yml up -d --build
```

`ipconfig.php` is generated automatically on first run if you skipped step 3 above.

Add `127.0.0.1 ivpl.local` to your `/etc/hosts` file first — the bundled nginx config expects
that hostname (see [resources/docker/README.md](../resources/docker/README.md) for why).

Access:
- **InvoicePlane**: http://ivpl.local
- **phpMyAdmin**: http://localhost:8081

#### Phase 3: Workflow (Daily Development)

1. **Make changes** to PHP or frontend files
2. **Rebuild assets** if needed: `yarn build` or `grunt watch`
3. **Test changes** at http://ivpl.local
4. **Run linters**: `composer check`
5. **Commit and push** your changes

For detailed workflow instructions, see [INSTALLATION.md - Development Workflow](docs/INSTALLATION.md#development-workflow).

### Coding Standards

- **PHP:** PSR-12 Standard
- **JavaScript:** Standard JS Code Formatting

### Testing

- Testing is very much appreciated, especially during Beta phases. Click through all functionalities of the application and check if you see weird behavior (for example: uploads not working anymore after a new Beta version of InvoicePlane), mention it in the community (Discord, community.invoiceplane.com forums) and see if an issue should be made.

### Branching Strategy

- `development` **Active** development
- `bugfix/*` For bug fixes. Please refer to an issue, if you have one.
- `feature/*` New features. Please refer to an issue, if you have one.

- `master` **Stable releases**. Every time a new version of InvoicePlane goes live, that same version is available in the `master` branch.

---

## Community and Support

- **[Community Forums](https://community.invoiceplane.com/)** - Ask questions and share knowledge.
- **[GitHub Issues](https://github.com/InvoicePlane/InvoicePlane/issues)** - Report bugs and request features.

---

## Code of Conduct

We follow a **Code of Conduct** to ensure a friendly and inclusive environment.
By contributing, you agree to abide by these principles.

For full details, see [CODE_OF_CONDUCT.md](CODE_OF_CONDUCT.md).

Happy Coding!
